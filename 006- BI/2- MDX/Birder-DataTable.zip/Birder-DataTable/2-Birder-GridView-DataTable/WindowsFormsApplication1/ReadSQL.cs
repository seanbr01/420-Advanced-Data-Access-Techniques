﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    class ReadSQL
    {
        public DataSet GetData()
        {
            //This  method uses datatables and dataAdapter

            // set up the SQL query string
            string queryString = "SELECT BirdCount.CountDate, Bird.Name, BirdCount.Counted FROM BirdCount " +
                " INNER JOIN Bird ON BirdCount.BirdID = Bird.BirdID";

            DataSet birdsDataSet = new DataSet("BirdsDataSet");   // Define a DataSet to hold our results

            SqlDataAdapter myDataAdapter = new SqlDataAdapter(); // instantiate, but prop's not set

            string connectionString = @"Server=N252-000\mssqlserver2; Database= Birds; Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);

            myDataAdapter.SelectCommand = new SqlCommand(queryString, connection); // create cmd and set its props

            try
            {
                myDataAdapter.Fill(birdsDataSet, "Region");
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
            return birdsDataSet;
        }
    }
}
