﻿using Microsoft.AnalysisServices.AdomdClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstReadCubeForm
{
    class ReadCube
    {
        public DataSet GetData()
        {
            // set up the SQL query string
            string queryString = " SELECT {[Measures].[Sales Amount], [Measures].[Order Quantity]} ON COLUMNS, " +
                " Non Empty { [Dim Sales Territory].[Sales Territory Country].Children} ON ROWS  " +
                " FROM [Adventure Works DW Cube] ";

            DataSet cubeDataSet = new DataSet();   // Define a DataSet to hold our results

            AdomdDataAdapter myDataAdapter = new AdomdDataAdapter(); // instantiate, but prop's not set

            string connectionString = @"Data Source=M-CS001483;Catalog=FirstCube";
            AdomdConnection connection = new AdomdConnection(connectionString);

            myDataAdapter.SelectCommand = new AdomdCommand(queryString, connection); // create cmd and set its props

            try
            {
                 myDataAdapter.Fill(cubeDataSet, "CubeData");
                }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
            return cubeDataSet;
        }
    }
}
