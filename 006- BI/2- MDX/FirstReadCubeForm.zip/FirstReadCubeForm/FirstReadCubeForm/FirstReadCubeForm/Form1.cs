﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirstReadCubeForm
{
    public partial class Form1 : Form
    {
        DataSet formsDataSet = new DataSet();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ReadCube myCubeReader = new ReadCube();
            try        
            {
		        formsDataSet = myCubeReader.GetData();
	        }
	        catch (Exception ex)
	        {
                labelAppMessages.Text = ex.Message;
	        }
            labelAppMessages.Text = "alls well";
            dataGridView1.DataSource = formsDataSet;
            dataGridView1.DataMember = "CubeData";
            dataGridView1.AutoResizeColumns();
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.BlanchedAlmond;
        }
    }
}
