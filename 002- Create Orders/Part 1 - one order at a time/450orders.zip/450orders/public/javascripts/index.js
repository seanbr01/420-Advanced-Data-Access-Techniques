document.addEventListener("DOMContentLoaded", function (event) {

    document.getElementById("button1").addEventListener("click", function () {

        document.getElementById("textbox1").value = "success";
    });

    document.getElementById("submit").addEventListener("click", function () {
        var person = {
            name: "kurt",
            age: 21
        }

          // putting the theSubject in the URL for the PUT method
    $.ajax({
        url: '/NewOrder/' ,
        method: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(person),
        success: function (result) {
          
        }

    });

    });
});