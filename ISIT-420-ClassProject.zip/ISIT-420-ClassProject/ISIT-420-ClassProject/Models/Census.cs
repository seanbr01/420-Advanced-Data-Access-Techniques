﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ISIT_420_ClassProject.Models
{
    public class Census
    {
        public int ID { get; set; }
        public int Year { get; set; }
        public long Population { get; set; }
    }
}