﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Products.Controllers
{
    public class NotesController : ApiController
    {
        // Note[] notes = new Note[]
        //List<Note> Notes = new List<Note>()
        //    {
        //new Note { NoteId = 1, Priority = 3, Subject = "Wake up", Details = "Set alarm 7:00 and get out of bed."},
        //new Note { NoteId = 2, Priority = 2, Subject = "Eat breakfast", Details = "Eat a healthy breakfast."},
        //new Note { NoteId = 3, Priority = 5, Subject = "Go to work", Details = "Get to work before 9:00 am."}
        //    };

        NoteModelContainer myNotes = new NoteModelContainer();


        // GET: Notes
        public IEnumerable<Note> GetAllNotes()
        {
            return myNotes.Notes.ToList();
        }

        public IHttpActionResult GetNote(int id)
        {
            var oneNote = myNotes.Notes.FirstOrDefault((p) => p.NoteId == id);
            if (oneNote == null)
            {
                return NotFound();
            }
            return Ok(oneNote);
        }


        [HttpPost]
        public IHttpActionResult Save(Note newNote)
        {
            myNotes.Notes.Add(newNote);
            myNotes.SaveChanges();
            return Ok();
        }

        [HttpDelete]
        public HttpResponseMessage Delete(string id)
        {
            bool found = true;
            string subject = id;
            // Remove the entity from the entity collection  
            Note note = myNotes.Notes.FirstOrDefault((p) => p.Subject == subject);
            if (note != null)
            {
                myNotes.Notes.Remove(note);
                myNotes.SaveChanges();
            }
            else
            {
                found = false;
            }
            HttpResponseMessage response = new HttpResponseMessage();
            if (!found)
            {
                response.StatusCode = HttpStatusCode.BadRequest;
                return response;
            }
            else
            {
                response.StatusCode = HttpStatusCode.OK;
                return response;
            }
        }



    } // end class

}
