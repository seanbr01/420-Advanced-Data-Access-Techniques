﻿
var uri = 'api/Notes';

$(document).on('pagebeforeshow ', '#pageone', function () {   // see: https://stackoverflow.com/questions/14468659/jquery-mobile-document-ready-vs-page-events
 
    GetShowData();  // this will update the page after any delete or add when the user clicks back to here.
   
});




function GetShowData() {
    $("#notes").empty();
    // Send an AJAX request
    $.getJSON(uri)
        .done(function (data) {
            // On success, 'data' contains a list of products.
            // had to add encodeURI to my data-parm to not lose spaces and text 
            $.each(data, function (index, record) {   // make up each li as an <a> to the details-page
                $('#notes').append('<li><a data-transition="pop" data-parm=' + encodeURI(record.Subject) + ' href="#details-page">' + record.Priority + ' => ' + record.Subject + '</a></li>');
                //console.log(record.Subject);
            });
            // // need this so jquery mobile will apply the styling to the newly added li's
            $("#notes").listview("refresh");
            $("a").on("click", function (event) {    // set up an event, if user clicks any <a>, it writes that items data-parm into the 
                var parm = $(this).attr("data-parm");  // passing in the record.Subject as coded just above
                //grab this list items data-parm and write it into the details page
                $("#detailParmHere").html(parm);
            });
        });
}


$(document).on('pagebeforeshow', '#details-page', function () {
    var vPriority;
    var vSubject;
    var vDetails;
    var id = $('#detailParmHere').text(); // get the subject text out of our hidden element
    $.getJSON(uri + '/' + id)
        .done(function (data) {
            vPriority = "Priority: " + data.Priority;
            vSubject = " Subject: " + data.Subject;
            vDetails = " Details: " + data.Details;
            //console.log(vPriority);
            //console.log(vSubject);
            //console.log(vDetails);
            $('#showdata').text(vPriority).append('<br />');; //display to details page
            $('#showdata').append(vSubject).append('<br />');;
            $('#showdata').append(vDetails);
        })
        .fail(function (jqXHR, textStatus, err) {
            $('#showdata').text('Error: ' + err);
        });

});


function deleteNote() {
    var id = $('#deleteNote').val();
    $.ajax({
        url: uri + "/" + id,
        type: "DELETE",
        contentType: "application/json",
        success: function () {
            $("#notes").empty();
            GetShowData();  
            $('#deleteResponse').text("Success: Note Deleted");
            $("#deleteNote").val('');
        },
        error: function () {
            $('#deleteResponse').text("Error: Delete Failed");
        }
    });
};


function saveNote() {
    $('#saveResponse').text = '';
    $("#notes").empty();
    var note = {
        subject: $('#Subject').val(),
        details: $('#Details').val(),
        priority: $('#Priority').val()
    };

    $.ajax({
        url: uri + "/Notes",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify(note),
        success: function (data) {
            //self.notes.push(data);
            $("#notes").empty();
            GetShowData();
            $('#saveResponse').text("Success: Saved Note");
            $("#Subject").val('');
            $("#Details").val('');
            $("#Priority").val('');
        },
        error: function () {
            $('#saveResponse').text("Error: Save Failed");
        }
    });
}