﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace _450Orders.Controllers
{
    public class FbiController : ApiController
    {
        ISIT420Entities ISIT420Entities = new ISIT420Entities();

        [Route("api/Fbi/GetAll")]
        [HttpGet]
        public IHttpActionResult GetAllFbis()
        {
            ISIT420Entities.Configuration.ProxyCreationEnabled = false;
            return Json(ISIT420Entities.FBIs);
        }
    }
}
