﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _450Orders.Models
{
    public class Fbi
    {
        public int ID { get; set; }
        public int Year { get; set; }
        public double Murder { get; set; }
        public double ViolentCrime { get; set; }
        public double Rape { get; set; }
        public double Robbery { get; set; }
        public double Assault { get; set; }
        public double ProptertyCrime { get; set; }
        public double Burglary { get; set; }
        public double LarcenyTheft { get; set; }
        public double MoterVehicleTheft { get; set; }
    }
}